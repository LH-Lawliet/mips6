#!/bin/sh

export TOOLCHAIN=/opt/arm/gcc-arm-none-eabi-10.3-2021.10
export SDK_ELEC=../sdk
export PATH=$SDK_ELEC/bin:$TOOLCHAIN/bin:$PATH
